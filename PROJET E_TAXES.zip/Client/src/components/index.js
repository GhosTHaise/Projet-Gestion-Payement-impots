import Home from "./home"
import Dashboard from "./Dashboard"
import { Login,Register } from "./Auth"
export  {
    Home,
    Login,
    Register,
    Dashboard
}