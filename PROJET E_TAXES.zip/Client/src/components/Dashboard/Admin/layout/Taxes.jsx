const Taxes = () => {
  return (
    <div>Taxes</div>
  )
}

export default Taxes