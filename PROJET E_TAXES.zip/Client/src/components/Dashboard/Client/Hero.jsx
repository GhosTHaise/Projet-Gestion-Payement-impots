import React from 'react'

const Hero = () => {
  return (
    <div>
      <h1>
        Welcome
      </h1>
    </div>
  )
}

export default Hero