import SideBar from "../SideBar"
import Hero from "./Hero"
const index = () => {
  return (
    <div>
        <Hero />
    </div>
  )
}

export default index