const impotRoutes = require("./impots");
const loginRoutes = require("./login")
const userRoutes = require("./user")
module.exports = {
    impotRoutes,
    loginRoutes,
    userRoutes
}