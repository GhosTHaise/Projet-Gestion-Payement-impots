const loginController = require("./loginController");
const userController = require("./userController")
const impotController = require("./impotController");

module.exports = {
    loginController,
    userController,
    impotController
}