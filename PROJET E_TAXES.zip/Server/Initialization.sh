#!/bin/bash
echo "Thanks for using my app 👻"

npm install
npm install sass
npm run start
